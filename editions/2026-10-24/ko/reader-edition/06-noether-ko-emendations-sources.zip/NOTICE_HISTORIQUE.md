# 한국어판 v1.0.0 (2026-08-13)의 권리 표시

다음은 이전 판본에 실린 표시의 원문이다. 그 범위는 해당 판본과 표시자가 실제로 보유했던 권리에 한정되며, 현재 판본 전체에 대한 새로운 이용허락을 뜻하지 않는다.

```text
CC0 1.0 Universal (CC0-1.0)

에미 뇌터는 1935년에 사망하였으므로, 그의 저작은 유럽연합과 보호기간이 저작자 사후 70년에 끝나는 모든 곳에서 퍼블릭 도메인에 속한다. 미국에서는 1931년 이후 처음 발표된 논문이 발표 후 95년까지 보호된다(1931년의 논문은 2027년 1월 1일에 자유로워진다). 발행자가 AI가 제작한 번역·수정·조판에 대하여 권리를 가지는 범위에서, 그 권리는 [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.ko)에 따라 퍼블릭 도메인에 기증된다. M. Deuring이 기록한 강의, H. Kapferer의 논문과 명시된 공동 저자의 기여는 이 표시의 대상이 아니며, 그 권리는 저작자 또는 그 상속인에게 남는다.

https://creativecommons.org/publicdomain/zero/1.0/legalcode

Emmy Noether's original works are not relicensed by this notice. They are
reproduced as public-domain scholarly works where applicable. German editorial
materials, institutional facsimiles, third-party evidence, fonts, software,
and other incorporated material retain their own legal status and licenses.
The release does not redistribute the Malgun Gothic or Times New Roman fonts
used to generate the reader.
```
