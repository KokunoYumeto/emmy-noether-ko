# 에미 뇌터 — 수학 저작집 한국어판

논문 1–43, M. Deuring이 기록한 1929/30년 강의, Kapferer와 Noether의 논문 및 보충문, 참고문헌과 권말 목록을 수록한다.

[전체 본문의 LaTeX](02-noether-ko.tex)는 외부 본문 입력 없이 해당 판본 전체를 담는다. 분할 원본은`reader.tex`, `p01.tex`–`p43.tex`, `post_a.tex`, `post_b.tex`, `back.tex`에 보존한다. `publication.tex`도 같은 주 파일을 사용한다. `p09_tail.tex`의 본문은 이미 `p09.tex`에 들어 있으므로 따로 다시 입력하지 않는다. 교정판의 편집 주석은 별도 파일로도 제공한다.

## 조판

XeLaTeX를 사용한다. Malgun Gothic과 Times New Roman 글꼴 및 fontspec, AMS, mathrsfs, mathtools, TikZ, hyperref, adjustbox, diagbox 등 프리앰블에 명시된 패키지가 필요하다. 글꼴은 동봉하지 않는다.

압축을 푼 폴더에서 다음 명령을 실행한다. 목차와 참조가 안정될 때까지 다시 실행한다.

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error 02-noether-ko.tex
```

분할 파일로 조판하려면 파일명을 `reader.tex`로 바꾼다.

AI가 번역한 한국어 본문이다. 초기 제작 주체: Manuscript Typesetting Project / OpenAI Codex(당시의 정확한 모델은 미확정). 이 판본의 AI 제작 수정과 조판: OpenAI Codex — GPT-6 Astra, Ultra 추론 설정; Claude Opus 5.5(Anthropic), 2026년 10월 26–27일(수식은 Noether의 인쇄면에서 읽은 독일어 본문과 대조).

[저자·출처·권리](RIGHTS.md) · [이전 판본의 권리 표시](NOTICE_HISTORIQUE.md)

`python build.py`는 XeLaTeX를3회 실행하며 제공 PDF와 같은 고정 조판시각 설정을 사용한다. PDF내부의 조판일은 공개일이 아니다. 사용 엔진: XeTeX3.141592653-2.6-0.999998 (MiKTeX26.5). 직접 내려받는LaTeX와ZIP의`02-noether-ko.tex`는 동일한 파일이다.
